import { LockFactory } from '@node-power-tools/concurrent-tools';
import { NptLogger } from '@node-power-tools/logging-tools';
import { KeyGenStrategy } from '@node-power-tools/npt-common';
declare type LockDecoratorFunction = (cacheKeyGenStrategy: KeyGenStrategy, keyGenArgs: any[], lockTtlSeconds: number) => Function;
/**
 * Build a lock decorator function
 *
 * @param lockFactory The lock factory to use for the generated decorator
 * @param logger Log object to use
 */
export declare function buildLockDecorator(lockFactory: LockFactory, logger: NptLogger): LockDecoratorFunction;
export {};
