import { NptLogger } from '@node-power-tools/logging-tools';
import { Cache, CacheConfig } from './cache';
import { KeyGenStrategy } from '@node-power-tools/npt-common';
export declare type KeyGeneratorFunction = (keyGenStrategy?: KeyGenStrategy, keyGenArgs?: any[], regionName?: string) => Function;
export declare type CacheConfigLookupFunction = (cacheName: string) => NonNullable<CacheConfig>;
/**
 * Build a cache decorator function
 *
 * @param cache The cache to use
 * @param cacheConfigLookupFunction Function that provides lookup for cache configuration
 * @param logger Logger to use
 */
export declare function buildCacheDecorator(cache: Cache, cacheConfigLookupFunction: CacheConfigLookupFunction, logger: NptLogger): KeyGeneratorFunction;
