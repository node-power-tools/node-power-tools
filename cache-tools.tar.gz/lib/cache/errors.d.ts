/**
 * Error thrown on cache codec registry errors
 */
import { NPTError } from '@node-power-tools/npt-common';
export declare class CodecRegistryError extends NPTError {
    constructor(message: string, cause?: Error);
}
