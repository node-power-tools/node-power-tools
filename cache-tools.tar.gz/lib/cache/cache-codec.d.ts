import { Optional } from '@node-power-tools/npt-common';
export declare const CACHE_REGION_PREFIX = "CACHE_";
export declare const CACHE_KEY_DELIMITER = "::";
export declare const CACHE_CODEC_DELIMITER = "@@";
export declare class CodecRegistry {
    private readonly codecByIdMap;
    private readonly codecByClassMap;
    /**
     * Register a cache codec
     *
     * @param codec The codec
     */
    registerCodec(codec: CacheCodec): void;
    getCodecInstance(codecId: string): CacheCodec;
}
/**
 * Global codec registry
 */
export declare const codecRegistry: CodecRegistry;
/**
 * Cache serialization codec.
 *
 * Note that all codecs must be registered with CodecRegistry at runtime.
 */
export declare abstract class CacheCodec {
    /**
     * A unique identifier for this codec - must be unique across all codecs as
     * the id is serialized as part of the cached data to use for de-serialization
     */
    abstract getId(): string;
    /**
     * Do the encoding for the raw object here
     *
     * @param rawObject The raw object
     */
    protected abstract encodeInternal<T>(rawObject: T): string;
    /**
     * Do the decoding from the encoded object here
     *
     * @param encodedObjectString The string representing the encoded object
     */
    protected abstract decodeInternal<T>(encodedObjectString: string): T;
    /**
     * Encode the raw object.  Prefix with the codec id
     *
     * @param rawObject The raw object to encode
     */
    encode<T>(rawObject: T): string;
    /**
     * Decode the encoded object using the codec indicated by the id in the
     * encodedObject string
     *
     * @param encodedObjectString The encoded object string
     */
    static decode<T>(encodedObjectString: string | undefined | null): Optional<T>;
}
/**
 * A simple, naive codec for encoding/decoding objects to/from their serialized form.
 */
export declare class SimpleJsonCodec extends CacheCodec {
    static ID: string;
    getId(): string;
    protected encodeInternal<T>(rawObject: T): string;
    protected decodeInternal<T>(encodedObject: string): T;
}
/**
 * Build a cache key region prefix
 *
 * @param cacheRegion The cache region name
 * @return The prefix
 */
export declare const buildCacheKeyRegionPrefix: (cacheRegion: string) => string;
/**
 * Unfortuntely the node-redis library provides no sugar for maintaining hash map TTLs so we can't use HSET with
 * TTL.  To work around this, build the cache key with a region prefix to namespace cache entries :/
 *
 * @param cacheRegion The region name for the cache
 * @param cacheKey The key for the cache entry
 * @return The composite cache key
 */
export declare const buildRegionPrefixedCacheKey: (cacheRegion: string, cacheKey: string) => string;
/**
 * Extract the cache region name from a cache key
 *
 * @param cacheKey The key to operate on
 * @return The cache region name
 */
export declare const extractCacheRegionNameFromCacheKey: (cacheKey: string) => string;
/**
 * Extract the cache key name from a region prefixed cache key
 *
 * @param cacheKey The key to operate on
 * @return The cache region name
 */
export declare const extractKeyFromRegionPrefixedCacheKey: (cacheKey: string) => string;
