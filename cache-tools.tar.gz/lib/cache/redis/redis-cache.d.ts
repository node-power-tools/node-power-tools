import { IHandyRedis } from 'handy-redis';
import { AsyncFunctionInvocation, Cache, CacheConfig, PutRequest, ReadThroughRequest } from '../cache';
import { CacheKeyEntry, CacheManager } from '../cache-manager';
import { RedisLockFactory } from '@node-power-tools/concurrent-tools';
import { NptLogger } from '@node-power-tools/logging-tools';
import { Optional } from '@node-power-tools/npt-common';
export declare const DEFAULT_CACHE_REGION_NAME = "DEFAULT";
/**
 * Marker interface for Redis caches
 */
export interface RedisCache extends Cache, CacheManager {
}
/**
 * A Redis backed cache abstraction.
 *
 * Note: This implementation is not cluster aware.  If you require cluster support, consider using
 * https://github.com/gosquared/redis-clustr as your Redis client library.
 */
export declare class RedisCacheImpl implements RedisCache {
    private readonly _redisClient;
    private readonly _redisLockFactory;
    private readonly _log;
    constructor(redisClient: IHandyRedis, redisLockFactory: RedisLockFactory, logger: NptLogger);
    /**
     * Spread the provided cache configuration over the default configuration
     *
     * @param cacheConfig The optional partial cache configuration
     */
    static mergeCacheConfigWithDefault(cacheConfig?: Partial<CacheConfig>): CacheConfig;
    /**
     * Get from the cache
     *
     * @param cacheKey The cache
     * @param cacheRegion The optional cache region name - will be defaulted
     *        if not provided
     */
    get<T>(cacheKey: string, cacheRegion?: string): Promise<Optional<T>>;
    /**
     * Put a value into the cache
     *
     * @param putRequest The put request
     */
    put<T>(putRequest: PutRequest<T>): Promise<void>;
    /**
     * Read through a cache backed by Redis
     *
     * @param readThroughRequest A read through request
     * @return The value returned from the cache or calculated via {@link ReadThroughRequest#readFn}
     */
    readThrough<T>({ cacheRegion, cacheKey, fnInvocation, cacheConfig, }: ReadThroughRequest<T>): Promise<T>;
    /**
     * Handle a cache miss
     *
     * @param cacheKey The key to use
     * @param cacheConfig Cache configuration
     * @param fnInvocation The function invocation to call to calculate the new value
     */
    handleCacheMiss<T>(cacheKey: string, cacheConfig: CacheConfig, fnInvocation: AsyncFunctionInvocation<T>): Promise<T>;
    /**
     * Get active cache region names.
     *
     * @return {@link string[]} of cache region names
     */
    getCacheRegionNames(): Promise<string[]>;
    /**
     * Get active cache keys with their TTL.
     *
     * @return {@link CacheKeyEntry[]}
     */
    getCacheKeys(cacheRegionName: string): Promise<CacheKeyEntry[]>;
    /**
     * Invalidate a cache region.
     *
     * @param cacheRegionName The cache region to invalidate
     * @return true if invalidated, false otherwise
     */
    invalidateCacheRegion(cacheRegionName: string): Promise<boolean>;
    /**
     * Invalidate a cache key.
     *
     * @param cacheRegionName The cache region name for the cache key to invalidate
     * @param cacheKey The cache key to invalidate
     * @return true if invalidated, false otherwise
     */
    invalidateCacheKey(cacheRegionName: string, cacheKey: string): Promise<boolean>;
}
