import { NptLogger } from './logger';
import { DateTimeFormatter } from '@js-joda/core';
/**
 * A very basic console logger
 */
export declare class ConsoleLogger implements NptLogger {
    static readonly DT_FORMAT: DateTimeFormatter;
    static newInstance(): ConsoleLogger;
    private handleLogMessage;
    all(msg: string, ...metadata: any[]): ConsoleLogger;
    debug(msg: string, ...metadata: any[]): ConsoleLogger;
    error(msg: string, ...metadata: any[]): ConsoleLogger;
    info(msg: string, ...metadata: any[]): ConsoleLogger;
    trace(msg: string, ...metadata: any[]): ConsoleLogger;
    warn(msg: string, ...metadata: any[]): ConsoleLogger;
}
