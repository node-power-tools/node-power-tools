import { NptLogger } from './logger';
import { Logger } from 'winston';
/**
 * A Winston logger wrapper
 */
export declare class WinstonLogger implements NptLogger {
    readonly _wrapped: Logger;
    private constructor();
    static wrap(logger: Logger): WinstonLogger;
    private handleLogMessage;
    all(msg: string, ...metadata: any[]): WinstonLogger;
    debug(msg: string, ...metadata: any[]): WinstonLogger;
    error(msg: string, ...metadata: any[]): WinstonLogger;
    info(msg: string, ...metadata: any[]): WinstonLogger;
    trace(msg: string, ...metadata: any[]): WinstonLogger;
    warn(msg: string, ...metadata: any[]): WinstonLogger;
}
