# logging-tools

## Running unit tests

Run `yarn nx test logging-tools` to execute the unit tests via [Jest](https://jestjs.io).
