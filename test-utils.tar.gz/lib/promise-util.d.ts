export declare const buildPromise: <T>(dataObject: T) => Promise<T>;
