# test-utils

## Running unit tests

Run `yarn nx test test-utils` to execute the unit tests via [Jest](https://jestjs.io).
