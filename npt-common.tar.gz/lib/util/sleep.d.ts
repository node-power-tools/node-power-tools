/**
 * Async sleep for the specified period of time in milliseconds
 *
 * @param sleepTimeMs Time in milliseconds to sleep
 */
export declare const sleep: (sleepTimeMs: number) => Promise<number>;
