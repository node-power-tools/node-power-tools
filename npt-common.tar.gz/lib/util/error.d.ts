import { VError } from 'verror';
export declare const toErrorStack: (e: Error) => string;
/**
 * Base error type
 */
export declare abstract class NPTError extends VError {
    protected constructor(name: string, message: string, cause?: Error);
}
/**
 * Cache error
 */
export declare class CacheError extends NPTError {
    constructor(message: string, cause?: Error);
}
