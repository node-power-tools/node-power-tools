/**
 * T or {@code undefined}.
 */
export declare type Optional<T> = T | undefined;
/**
 * Simple async function type
 */
export declare type AsyncFunction<R> = (...args: any[]) => Promise<R>;
