# npt-common

## Running unit tests

Run `yarn nx test npt-common` to execute the unit tests via [Jest](https://jestjs.io).
