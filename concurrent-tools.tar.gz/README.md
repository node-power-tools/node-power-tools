# concurrent-tools

## Running unit tests

Run `yarn nx test concurrent-tools` to execute the unit tests via [Jest](https://jestjs.io).
