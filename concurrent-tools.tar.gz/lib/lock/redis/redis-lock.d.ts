import { Lock, LockConfig } from '../lock';
import { IHandyRedis } from 'handy-redis';
import { NptLogger } from '@node-power-tools/logging-tools';
import { Instant } from '@js-joda/core';
export declare const REDIS_LOCK_PREFIX = "LOCK_";
export declare const SUCCESS_RES = "OK";
/**
 * Marker interface for Redis locks
 */
export declare type RedisLock = Lock;
/**
 * A simple, non-distributed Redis lock (mutex) implementation that supports retries if the lock is currently
 * held by another client.
 */
export declare class SimpleRedisLockImpl implements RedisLock {
    private readonly _log;
    private readonly _redisClient;
    private readonly _lockConfig;
    private readonly _lockKey;
    private readonly _lockTtlSeconds;
    private readonly lockUuid;
    private locked;
    constructor(log: NptLogger, redisClient: IHandyRedis, lockConfig: LockConfig, lockKey: string, lockTtlSeconds: number);
    calcRetrySleepTime(): number;
    calcEndRetryInstant(startInstant: Instant): Instant;
    getLockKey(): string;
    tryAcquire(): Promise<boolean>;
    acquire(): Promise<boolean>;
    release(quiet?: boolean): Promise<boolean>;
}
