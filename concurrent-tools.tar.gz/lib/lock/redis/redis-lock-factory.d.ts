import { Lock, LockConfig } from '../lock';
import { LockFactory } from '../lock-factory';
import { NptLogger } from '@node-power-tools/logging-tools';
import { IHandyRedis } from 'handy-redis';
export declare type RedisLockFactory = LockFactory;
/**
 * A simple Redis lock factory
 */
export declare class RedisLockFactoryImpl implements RedisLockFactory {
    private _logger;
    private _redisClient;
    private _lockConfig;
    constructor(redisClient: IHandyRedis, lockConfig: LockConfig, logger: NptLogger);
    createLock(lockKey: string, lockTtlSeconds: number, redisLockConfig?: Partial<LockConfig>): Lock;
}
